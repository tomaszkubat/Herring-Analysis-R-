library(shiny)
library(knitr)
library(rstudioapi)
library(ggplot2)
library(dplyr)
library(tidyr)

globalParam <- list() # empty list for global params
globalParam$wd = dirname(rstudioapi::getSourceEditorContext()$path) # get and save working directory
setwd(globalParam$wd) # set wd


# load data (only once)
df <- read.csv('./www/data/filmdeathcounts.csv')
df$Decade <- floor(df$Year/10) * 10
dfSep <- separate_rows(df, Genre, sep = c('[^[:alnum:].]+'))

# aggregate total/average number of kills by Director
dfSummDir <- select(df, Director, Body_Count) %>%
  group_by(Director) %>%
  summarize(
    total_kills=sum(Body_Count),
    average_kills=round(mean(Body_Count),0),
    number_of_films=n()
  ) %>%
  arrange(desc(total_kills)) %>%
  top_n(20, total_kills)

# aggregate total/average number of kills by Genre
dfSummGen <- select(dfSep, Genre, Body_Count) %>%
  group_by(Genre) %>%
  summarize(
    total_kills=sum(Body_Count),
    average_kills=round(mean(Body_Count),0),
    number_of_films=n()
  ) %>%
  arrange(desc(average_kills)) %>%
  top_n(20, average_kills)



shinyServer(function(input, output) {
  output$outPloTimeDec <- renderPlot({
    ggplot(filter(dfSep, Genre == input$inpGenre & IMDB_Rating >= input$inpRat[1] & IMDB_Rating <= input$inpRat[2]), aes(x=Length_Minutes, y=Body_Count, col=MPAA_Rating)) +
      geom_point() +
      facet_grid(. ~ Decade) +
      theme_bw()
  })
  output$outTblSumm1 <- renderTable(dfSummDir)
  output$outTblSumm2 <- renderTable(dfSummGen)
  
})
