library(shiny)
library(rstudioapi)
library(dplyr)
library(tidyr)

globalParam <- list() # empty list for global params
globalParam$wd = dirname(rstudioapi::getSourceEditorContext()$path) # get and save working directory
setwd(globalParam$wd) # set wd


df <- read.csv('./www/data/filmdeathcounts.csv')

genre <- select(df, Genre) %>%
  separate_rows(Genre, sep = c('[^[:alnum:].]+')) 
genre <- as.list(genre[,1])
genre <- unlist(unique(genre))

rat <- df$IMDB_Rating

shinyUI(fluidPage(
  titlePanel('Film death count'),
  sidebarLayout(
    sidebarPanel(
      selectInput('inpGenre', 'Choose genre to generate dynamic output:', choices = genre),
      sliderInput("inpRat", "Set IMDB rating:", min=min(rat), max=max(rat), value=c(min(rat),max(rat)))
    ),
    mainPanel(
      h2('dynamic visualization'),
        plotOutput('outPloTimeDec'),
      h2('static summary'), 
        tableOutput('outTblSumm1'),
        tableOutput('outTblSumm2'),
        p('One film could be assigned/calculated in the few genres.')
    )
  )
))